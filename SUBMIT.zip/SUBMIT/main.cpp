#include "log.cpp"

int main() {
    log("test","test");
}